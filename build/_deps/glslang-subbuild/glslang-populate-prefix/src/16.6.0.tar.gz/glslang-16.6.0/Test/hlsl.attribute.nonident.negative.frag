void f() {
    ['
